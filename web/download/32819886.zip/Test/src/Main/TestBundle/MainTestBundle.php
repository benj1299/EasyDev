<?php

namespace Main\TestBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MainTestBundle extends Bundle
{
}
