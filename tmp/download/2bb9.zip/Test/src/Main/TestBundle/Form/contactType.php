<?php
namespace Main\TestBundle\Form;
        
use Symfony\Component\Form\AbstractType;
use Symfony\Component\Form\FormBuilderInterface;
use Symfony\Component\Form\Extension\Core\Type\TextType;
use Symfony\Component\Form\Extension\Core\Type\EmailType;
use Symfony\Component\Form\Extension\Core\Type\TextareaType;
use Symfony\Component\Form\Extension\Core\Type\SubmitType;

        
class contactType extends AbstractType
{
    public function buildForm(FormBuilderInterface $builder, array $options)
    {
        $builder
		->add('form', ::class, ['required' => false, 'attr' => [  'class' => 'contact-form'], 'label' => false])
		->add('name', TextType::class, ['required' => false, 'attr' => [  'class' => 'contact-name'], 'label' => false])
		->add('email', EmailType::class, ['required' => false, 'attr' => [  'class' => 'contact-email'], 'label' => false])
		->add('message', TextareaType::class, ['required' => false, 'attr' => [  'class' => 'contact-message'], 'label' => false])
	}
 }