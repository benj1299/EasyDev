<?php

namespace Main\EdBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class MainEdBundle extends Bundle
{
}
