<?php
exec('cd '.__DIR__);
exec('php composer.phar update');
exec('rm -rf composer.phar');
exec('php bin/console cache:clear');
exec('php bin/console assets:install');
exec('rm -rf install.php');